//
//  ViewController.swift
//  pfinal
//
//  Created by Macbook on 11/15/18.
//  Copyright © 2018 iosdevlab. All rights reserved.
//

import UIKit
import EventKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    let eventStore = EKEventStore()
    
    var calendars: [EKCalendar] = [EKCalendar]()
    
    @IBOutlet weak var NotaRapida: UIButton!
    @IBOutlet weak var Recordatorio: UIButton!
    @IBOutlet weak var AdministracionMaterias: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    tableView.dataSource = self
        
    NotaRapida.layer.cornerRadius = 12
    Recordatorio.layer.cornerRadius = 12
    AdministracionMaterias.layer.cornerRadius = 12
   
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        checkPermission()
    }
    
    
    func checkPermission(){
        switch EKEventStore.authorizationStatus(for: .event) {
        case .authorized:
            print("Se autorizo el uso")
            loadData()
        case .notDetermined:
            print("No se autorizo")
            eventStore.requestAccess(to: .event, completion: {(isAllowed, error)
                in
                if let error = error{
                    print(error.localizedDescription)
                }else{
                    if isAllowed{
                        self.loadData()
                    }
                }
                
            })
        case .restricted, .denied:
            print("...")
        }
    }
    
    func loadData(){
        print("Start Loading Calendar")
        
        print(eventStore.calendars(for: .event))
        
        calendars = eventStore.calendars(for: .event)
        tableView.reloadData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
}

extension ViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return calendars.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let calendar = calendars[indexPath.row]
        
        cell.textLabel?.text = calendar.title
        
        return cell
    }
}

