//
//  ViewControllerNote.swift
//  pfinal
//
//  Created by CARLOS DANIEL LORENZO VALDEZ on 12/2/18.
//  Copyright © 2018 iosdevlab. All rights reserved.
//
import UIKit
import SafariServices

class ViewControllerNote: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var tableViewNote: UITableView!
    @IBOutlet weak var addVideoTextField: UITextField!
    var videos: [String] = ["Nota","nota"]
    override func viewDidAppear(_ animated: Bool){
        tableViewNote.tableFooterView = UIView(frame: CGRect.zero)
    }
    @IBAction func addButtonTapped(_ sender: YTRoundedButton) {
        insertNewVideoTitle()
    }
    func insertNewVideoTitle() {
        videos.append(addVideoTextField.text!)
        let indexPath = IndexPath(row: videos.count-1, section: 0)
        tableViewNote.beginUpdates()
        tableViewNote.insertRows(at: [indexPath], with: .automatic)
        tableViewNote.endUpdates()
        addVideoTextField.text = ""
        view.endEditing(true)
    }
}
extension ViewControllerNote: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return videos.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let videoTitle = videos[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "VideoCell") as! VideoCell
        cell.videoTitle.text = videoTitle
        
        return cell
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            videos.remove(at: indexPath.row)
            tableView.beginUpdates()
            tableView.deleteRows(at: [indexPath], with: .automatic)
            tableView.endUpdates()
        }
    }
}
