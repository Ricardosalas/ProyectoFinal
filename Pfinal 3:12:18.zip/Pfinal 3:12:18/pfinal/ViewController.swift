//
//  ViewController.swift
//  pfinal
//
//  Created by Macbook on 11/15/18.
//  Copyright © 2018 iosdevlab. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {
    @IBOutlet weak var NotaRapida: UIButton!
    @IBOutlet weak var AdministracionMaterias: UIButton!
    @IBOutlet weak var Recordatorio: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    NotaRapida.layer.cornerRadius = 12
    AdministracionMaterias.layer.cornerRadius = 12
    Recordatorio.layer.cornerRadius = 12
    }
}
