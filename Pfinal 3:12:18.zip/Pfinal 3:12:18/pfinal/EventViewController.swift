//
//  EventViewController.swift
//  pfinal
//
//  Created by Macbook on 11/30/18.
//  Copyright © 2018 iosdevlab. All rights reserved.
//

import UIKit
import EventKit

class EventViewController: UIViewController {
    
    static let identifier = "eventVC"
    
    let eventStore = EKEventStore()
    
    var events : [EKEvent] = [EKEvent]()
    
    var calendar: EKCalendar!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        loadEvents()
    }
    
    func loadEvents(){
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "DD/MM/AAAA"
        let startDate = dateFormat.date(from: "01/10/2018")
        let endDate = dateFormat.date(from: "31/12/18")
        
        let eventPredicate = eventStore.predicateForEvents(withStart: startDate!, end: endDate!, calendars: [calendar])
        
        events = eventStore.events(matching: eventPredicate).sorted { (event1, event2) -> Bool in
            return event1.startDate.compare(event2.startDate) == ComparisonResult.orderedAscending
        }
        print(events)
    }
   

}
