//
//  ViewControllerRecordatorio.swift
//  pfinal
//
//  Created by CARLOS DANIEL LORENZO VALDEZ on 12/2/18.
//  Copyright © 2018 iosdevlab. All rights reserved.
//

import UIKit
import EventKit

class ViewControllerRecordatorio: UIViewController {
    @IBOutlet weak var tableViewRec: UITableView!
    
    let eventStore = EKEventStore()
    var calendars: [EKCalendar] = [EKCalendar]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewRec.dataSource = self
        tableViewRec.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        checkPermission()
    }
    
    func checkPermission(){
        switch EKEventStore.authorizationStatus(for: .event) {
        case .authorized:
            print("Se autorizo el uso")
            loadData()
        case .notDetermined:
            print("No se autorizo")
            eventStore.requestAccess(to: .event, completion: {(isAllowed, error)
                in
                if let error = error{
                    print(error.localizedDescription)
                }else{
                    if isAllowed{
                        self.loadData()
                    }
                }
                
            })
        case .restricted, .denied:
            print("...")
        }
    }
    
    func loadData(){
        calendars = eventStore.calendars(for: .event)
        tableViewRec.reloadData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}


extension ViewControllerRecordatorio : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return calendars.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let calendar = calendars[indexPath.row]
        
        cell.textLabel?.text = calendar.title
        
        return cell
    }
}
extension ViewControllerRecordatorio : UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let calendar = calendars[indexPath.row]
        
        guard let eventVC = self.storyboard?.instantiateViewController(withIdentifier: EventViewController.identifier)as? EventViewController else {return}
        eventVC.calendar = calendar
        
        self.navigationController?.pushViewController(eventVC, animated: true)
    }
}
    


