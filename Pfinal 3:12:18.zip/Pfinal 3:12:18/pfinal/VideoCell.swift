//
//  VideoCell.swift
//  pfinal
//
//  Created by CARLOS DANIEL LORENZO VALDEZ on 12/3/18.
//  Copyright © 2018 iosdevlab. All rights reserved.
//

import UIKit

class VideoCell: UITableViewCell {
    
    @IBOutlet weak var videoTitle: UILabel!
}
